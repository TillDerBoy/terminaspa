import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TaskaddComponent } from './taskadd/taskadd.component';
import { TaskallComponent } from './taskall/taskall.component';

const routes: Routes = [
  {path: 'LinkTaskall', component:TaskallComponent},
  {path: 'LinkTaskadd', component:TaskaddComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
