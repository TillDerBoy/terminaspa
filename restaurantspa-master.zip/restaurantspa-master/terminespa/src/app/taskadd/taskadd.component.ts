import { Component, OnInit } from '@angular/core';
import { TaskService } from '../task-service';

@Component({
  selector: 'an-taskadd',
  templateUrl: './taskadd.component.html',
  styleUrls: ['./taskadd.component.css']
})
export class TaskaddComponent implements OnInit {
//Hier wird die get methode von task-serve aufgerufen
  constructor(private taskservice: TaskService) { }
  ngOnInit() { }
  taskname = '';
  taskdescription = '';
  taskpriority = '';
  storeDataOnDB(): void {
  alert('Text changed to' + this.taskname + this.taskdescription + this.taskpriority);
  let task = {
  name: this.taskname,
  description: this.taskdescription,
  priority: parseInt(this.taskpriority)
  };
  this.taskservice.addData(task);
  }

}
