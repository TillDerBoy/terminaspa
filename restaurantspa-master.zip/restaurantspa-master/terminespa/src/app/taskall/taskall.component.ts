import { Component, OnInit } from '@angular/core';
import { TaskService } from '../task-service';

@Component({
  selector: 'an-taskall',
  templateUrl: './taskall.component.html',
  styleUrls: ['./taskall.component.css']
})
export class TaskallComponent implements OnInit {

  public tasks: any;
  constructor(private taskservice: TaskService) {}
  ngOnInit() {
  this.taskservice.getData().subscribe(
  data => { this.tasks = data },
  err => console.log(err),
  () => console.log('loading done.')
  );
  }

}
