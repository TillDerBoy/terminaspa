import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';

const httpOptions = {
 headers: new HttpHeaders({
 'Content-Type': 'application/json'
 })
}
@Injectable()
export class TaskService {
 constructor(private http:HttpClient) {}
 //Hier sind die calls der storefront drinnen alle Gets Post Put delete
 getData() {
 return this.http.get('https://stark-earth-23954.herokuapp.com/api/v1.0/task/all');
 }
 addData(postTask: Object) {
 let endPoint = "https://stark-earth-23954.herokuapp.com/api/v1.0/task"
 this.http.post(endPoint, postTask).subscribe(data => {
 console.log(data);
 });
 }
}