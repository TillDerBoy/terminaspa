import { TaskService } from './task-service';

describe('TaskService', () => {
  it('should create an instance', () => {
    expect(new TaskService()).toBeTruthy();
  });
});
